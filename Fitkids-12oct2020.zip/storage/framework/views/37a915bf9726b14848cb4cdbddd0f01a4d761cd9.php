  
  <?php $__env->startSection('content'); ?>
  <style type="text/css">
    button.btn.btn-danger.btn-rounded {
      background: black !important;
      color: #fff !important;
      border-color: black;
  }
  button.btn.btn-danger.btn-rounded a {
      color: #fff;
  }
  input[type=file]
  {
    margin-top: 0px; 
    width: 100%
  }
textarea.form-control
{
  width: 98%;
} 
  @media (min-width: 768px){
  
  button.btn.btn-success.btn-rounded {
    margin-top: 15px;
    float: left;
}
  }
  </style>
    <div class="container-fluid"> 
      <!-- Title -->
      <div class="row heading-bg">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <h5 class="txt-dark" style="float: left;"><a class="btn btn-success" href="<?php echo e(url('report')); ?>">Monthly Report</a></h5>
          <h5 class="txt-dark" style="float: left;"><a class="btn btn-success" href="<?php echo e(url('report')); ?>">Monthly Report</a></h5>
        </div>
      </div>

      <!-- /Title --> 
      <!-- Row -->
      <div class="row">
      <!--   <div class="col-md-12 col-xs-12">
          <div class="panel panel-default card-view">
           
            <div class="panel-wrapper collapse in">
              <div class="panel-body">
                <div class="row">
                  <div class="col-md-12 col-xs-12">
                     <?php if(session()->has('message')): ?>
             <div class="alert alert-success">
                 <?php echo e(session()->get('message')); ?>

             </div>
                 <?php elseif(session()->has('emessage')): ?>
                           <div class="alert alert-danger">
                               <?php echo e(session()->get('emessage')); ?>

                           </div>
                 <?php endif; ?>
                    <div class="form-wrap">
                     
                      <form  method="POST" action="<?php echo url('admin/add_course'); ?>" enctype="multipart/form-data">
                          <?php echo csrf_field(); ?>
                         
                          <div class="col-sm-3 col-xs-12">
                            <div class="form-group">
                              <label class="control-label">Name</label>
                              <div>
                                <input type="text" name="name" class="form-control"  placeholder="Course name">
                                <?php if($errors->has('name')): ?>
                                      <p class="error" ><?php echo e($errors->first('name')); ?></p>
                                    <?php endif; ?>
                              </div>
                            </div>
                          </div>
                          
                         <div class="col-sm-3 col-xs-12">
                            <div class="form-group">
                              <label class="control-label">Fees</label>
                              <div>
                                <input type="number" name="fees" class="form-control"  placeholder="Fees">
                                <?php if($errors->has('fees')): ?>
                                      <p class="error" ><?php echo e($errors->first('fees')); ?></p>
                                    <?php endif; ?>
                              </div>
                            </div>
                          </div>
                          
                         
                     
                          
                          <div class="col-sm-12 col-xs-12 text-right" style="padding-left: 0">
                        <button class="btn  btn-success btn-rounded"><i class="mdi mdi-content-save  mr-5"></i> Save </button>
                      </div>
                      </form>
                      
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      -->
        <div class="col-md-12">
          <div class="panel panel-default card-view">
          
            <div class="panel-wrapper collapse in">
              <div class="panel-body">
                <div class="datatable-responsive table-responsive">
               
                  
                  <table id="simpletable1" class="table table-striped table-bordered nowrap">
<thead>
<tr>
<th> Year</th>
<th> Month</th>
<th> Total purchased courses</th>
<th> Total income</th>
<th> Total expenses</th>
<th> Profit</th>
</tr>
</thead>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<?php $monthNum = $user->month;
$dateObj = DateTime::createFromFormat('!m', $monthNum);
$monthName = $dateObj->format('F');?>
<td><?php echo e($user->year); ?></td>
<td><?php echo e($monthName); ?></td>
<td><?php echo e($user->courses); ?></td>
<td><?php echo e($user->total_amount); ?></td>
<td><?php echo e($user->expenses); ?></td>
<td><?php echo e($user->total_amount - $user->expenses); ?></td>
</tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                      <tr>
                      <th> Year</th>
<th> Month</th>
<th> Total purchased courses</th>
<th> Total income</th>
<th> Total expenses</th>
<th> Profit</th>
                      </tr>
                    </tfoot>

</table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>

<script type="text/javascript">
  $('#simpletable1').DataTable( {
    dom: 'Bfrtip',
    buttons: [
         'excel'
    ]
} );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laabhomc/public_html/sahiapp.com/fitkid.com/resources/views/admin/report.blade.php ENDPATH**/ ?>