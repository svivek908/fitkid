<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  
    <!-- BANNER -->
    <div class="section banner-page" data-background="<?php echo e(asset('images/banner-single.jpg')); ?>">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page">About Us</div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">About Us</li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>

    <!-- WHY CHOOSE US -->
    <div class="section">
        <div class="content-wrap pb-0">
            <div class="container">
                <div class="row align-items-end">
                    <div class="col-sm-12 col-md-12 col-lg-7">
                        <p class="supheading">Why Choose Us</p>
                        <h2 class="section-heading mb-5">
                            Best Kindergarten
                        </h2>
                        <p class="">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.  Praesent interdum est gravida vehicula est node maecenas loareet morbi a dosis luctus novum est praesent.  Praesent interdum est gravida vehicula est node maecenas loareet morbi a dosis luctus novum est praesent.</p>
                        <p class="p-check ">100% education, for your kids, consectetuer adipiscing elit, sed diam nonummy nibh euismod.</p>
                        <p class="p-check ">More programs activities, sed diam nonummy nibh euismod. Lorem ipsum dolor sit amet.</p>
                        <p class="p-check ">More benefit nonummy nibh euismod. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
                        <div class="spacer-90"></div>
                    </div>
                    <div class="col-sm-12 col-md-12 col-lg-5">
                        <img src="<?php echo e(asset('images/teacher_promo.png')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                
            </div>
        </div>
    </div>

  


   


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projects\fitkid.com\resources\views/about.blade.php ENDPATH**/ ?>