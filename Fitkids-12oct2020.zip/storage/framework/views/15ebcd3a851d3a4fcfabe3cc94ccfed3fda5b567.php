<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  <style type="text/css">
      a.btn.btn-secondary {
    font-size: 14px;
    color: #ffffff;
    padding: 14px 37px;
    border: 0;
    margin-right: 8px;
    min-width: 130px;
    -webkit-border-radius: 30px;
    -moz-border-radius: 30px;
    -ms-border-radius: 30px;
    border-radius: 30px;
}
.rs-box-testimony .quote-box .quote-name {
    margin-top: 30px;
    font-size: 18px;
    line-height: 34px;
    color: #FD4D40;
    text-align: center;
}
.supheading:before, .supheading:after {
    content: " - "; 
    display: none;
}
.owl-carousel, .bx-wrapper { direction: ltr; } 
  </style>
    <!-- BANNER -->
    <div id="oc-fullslider" class="banner">
        <div class="owl-carousel owl-theme full-screen">
            <?php if($banners): ?>
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <img src="<?php echo e(asset('admin-assets/Banner').'/'.$banner->image); ?>" alt="Slider">
                <div class="overlay-bg"></div>
                <div class="container d-flex align-items-center">
                    <div class="wrap-caption">
                        <h5 class="caption-supheading"><?php echo e(__('messages.Welcome to FitKid')); ?></h5>
                        <h1 class="caption-heading"><?php echo e($banner->title); ?></h1>
                      <!--   <a href="#" class="btn btn-secondary">LEARN MORE</a> -->
                    </div>  
                </div>
            </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div class="custom-nav owl-nav"></div>
    </div>  

    <!-- SHORTCUT -->
    <div class="section services">
        <div class="content-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <div class="row col-0 overlap no-gutters">
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <!-- BOX 1 -->
                                <div class="rs-feature-box-1 bg-primary">
                                    <i class="fa fa-clock-o"></i>
                                    <div class="body">
                                        <h4><?php echo e(__('messages.Full Day Programs')); ?></h4>
                                        <p><?php echo e(__('messages.Sedut perspiciatis unde omnis iste natus error sit voluptatem accusantium.')); ?></p>
                                        <a href="<?php echo e(url('/courses')); ?>" class="btn btn-secondary" style="margin-top: 17px"><?php echo e(__('messages.LEARN MORE')); ?></a>
                                        <div class="spacer-10"></div>
                                      
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <!-- BOX 2 -->
                                <div class="rs-feature-box-1 bg-secondary">
                                    <i class="fa fa-home"></i>
                                    <div class="body">
                                        <h4><?php echo e(__('messages.Full Day Programs')); ?></h4>
                                        <p><?php echo e(__('messages.Sedut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore mque laudantium')); ?></p>
                                         <a href="<?php echo e(url('/courses')); ?>" class="btn btn-secondary"><?php echo e(__('messages.LEARN MORE')); ?></a>
                                        <div class="spacer-10"></div>
                                      
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <!-- BOX 3 -->
                                <div class="rs-feature-box-1 bg-tertiary">
                                    <i class="fa fa-trophy"></i>
                                    <div class="body">
                                        <h4><?php echo e(__('messages.Full Day Programs')); ?></h4>
                                        <p><?php echo e(__('messages.Sedut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore mque laudantium')); ?></p>
                                         <a href="<?php echo e(url('/courses')); ?>" class="btn btn-secondary"><?php echo e(__('messages.LEARN MORE')); ?></a>
                                        <div class="spacer-10"></div>
                                    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>  

    <!-- WELCOME TO KIDS -->
    <div class="section">
        <div class="content-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-6">
                        <img src="<?php echo e(asset('images/imgpsh_fullsize_anim.png')); ?>" alt="" class="img-fluid img-border">
                    </div>
                    <?php if(Config::get('app.locale') == 'ar'): ?>
                     <div class="col-sm-12 col-md-12 col-lg-6 text-right">
                    <?php else: ?>
                         <div class="col-sm-12 col-md-12 col-lg-6">
                        <?php endif; ?>
                    <!--<div class="col-sm-12 col-md-12 col-lg-6">-->
                        <h2 class="section-heading">
                            <?php echo e(__('messages.Welcome to FitKid')); ?>

                        </h2>
                        <p>Our institution focuses on developing and improving:<br>
          <span>Selfconfidence and selfesteem</span></p>
          <span> Self defense</span><br>
        <span> Physical fitness</span><br>
        <span> Concentration</span><br>
        <span> Discipline</span><br>
        <span> Social skills</span><br><p></p>
                        <!--<p><?php print( __('messages.Teritatis et quasi architecto. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore mque laudantium, totam rem aperiam, eaque ipsa quae ab illo invent. Sed ut perspiciatis unde omnis iste natus error sitdolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod.  Praesent interdum est gravida vehicula est node maecenas loareet morbi a dosis luctus novum est praesent. Magna est consectetur interdum modest dictum.')); ?></p>-->
                        <!--<p><?php echo e(__('messages.Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore mque laudantium, totam rem aperiam, eaque ipsa quae ab illo invent.')); ?> </p>-->
                        
                        <a href="<?php echo e(url('/about')); ?>" class="btn btn-secondary"><?php echo e(__('messages.DISCOVER MORE')); ?></a>
                        <div class="spacer-30"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- FUNFACT -->
    <div class="section bgi-overlay bgi-cover-center" data-background="<?php echo e(asset('images/imgpsh_fullsize_animsss.png')); ?>">
        <div class="content-wrap">
            <div class="container">
                <div class="row">
                    <!-- Item 1 -->
                    <div class="col-sm-6 col-md-4">
                        <div class="rs-funfact bg-primary">
                            <div class="box-fun"><h2><?php echo e($student); ?></h2></div>
                            <div class="title"><?php echo e(__('messages.Students')); ?></div>   
                        </div>
                    </div>
                    <!-- Item 2 -->
                    <div class="col-sm-6 col-md-4">
                        <div class="rs-funfact bg-secondary">
                            <div class="box-fun"><h2><?php echo e($batches); ?></h2></div>
                            <div class="title"><?php echo e(__('messages.Batches')); ?></div>   
                        </div>
                    </div>
                    <!-- Item 3 -->
                    <div class="col-sm-6 col-md-4">
                        <div class="rs-funfact bg-tertiary">
                            <div class="box-fun"><h2><?php echo e($courses); ?></h2></div>
                            <div class="title"><?php echo e(__('messages.Courses')); ?></div>    
                        </div>
                    </div>
                  
                </div>
            </div>
        </div>
    </div>

    <!-- OUR ARTICLES -->
    <div class="">
        <div class="content-wrap">
            <div class="container">

                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <p class="supheading text-center"><?php echo e(__('messages.Our Programs')); ?></p>
                        <h2 class="section-heading text-center mb-5">
                            <?php echo e(__('messages.Popular Courses')); ?>

                        </h2>
                    </div>
                </div>

                <div class="row mt-4">
                    <?php if($course): ?>
                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Item <?php echo e($key); ?> -->
                    <div class="col-sm-12 col-md-12 col-lg-4">
                        <div class="rs-class-box mb-5">
                            <div class="media-box">
                                <img src="<?php echo e(asset('admin-assets/course').'/'.$courses->image); ?>" alt="" class="img-fluid"></div>
                            <div class="body-box">
                                <div class="class-name">
                                   <div class="title"><?php echo e($courses->name); ?></div>
                                    <div class="price"><?php echo e($courses->fees); ?>&nbsp;SAR</div>
                                </div>
                                  <div class="open-class"><?php echo e(__('messages.Open Class')); ?>: <span><?php echo e($courses->open_time_from); ?> - <?php echo e($courses->open_time_to); ?></span></div>
                                <div class="open-class">
                               <!--   <a href="#" class="btn btn-secondary">Buy now</a> -->
                                 <a href="<?php echo e(url('course_details').'/'.$courses->id); ?>" class="btn btn-secondary" style="margin-left: 25%;"><?php echo e(__('messages.More details')); ?></a>
                                </div>
                               <div class="detail">
                                    <div class="age col"><?php echo e(__('messages.Age')); ?> <?php echo e($courses->age_from); ?>-<?php echo e($courses->age_to); ?> <?php echo e(__('messages.years')); ?></div>
                                    <div class="size col"><?php echo e(__('messages.Class Size')); ?> <?php echo e($courses->class_size); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                 
                  

                </div>

                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <div class="text-center">
                            <a href="<?php echo e(url('/courses')); ?>" class="btn btn-primary"><?php echo e(__('messages.SEE MORE COURSES')); ?></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- WHY CHOOSE US -->
    <div class="section bgi-repeat" style="background: #f1c22e;">
        <div class="content-wrap pb-0" style="padding: 0px 0; margin-top: 50px;">
            <div class="container">
                <div class="row align-items-end" style="align-items: center!important;">
                    <div class="col-sm-12 col-md-12 col-lg-7" style="margin-bottom: 321px;">
                        <p class="supheading"><?php echo e(__('messages.Why Choose Us')); ?></p>
                        <h2 class="section-heading">
                            <?php echo e(__('messages.We transfer weakness to strength by boosting self-confidence and self esteem')); ?>

                        </h2>
                        <!--<h2 class="section-heading">-->
                        <!--    <?php echo e(__('messages.Best Karate Training Courses')); ?>-->
                        <!--</h2>-->
                        <!--<p class="text-white"><?php echo e(__('messages.Dolor sit amet, dolor gravida placerat liberolorem ipsum dolor consectetur adipiscing elit, sed do eiusmod. Dolor sit amet consectetuer adipiscing elit, sed diam nonummy nibh euismod. Praesent interdum est gravida vehicula est node maecenas loareet morbi a dosis luctus novum est praesent. Praesent interdum est gravida vehicula est node maecenas loareet morbi a dosis luctus novum est praesent.')); ?></p>-->
                        <!--<p class="p-check text-white"><?php echo e(__('messages.100% education, for your kids, consectetuer adipiscing elit, sed diam nonummy nibh euismod. Dolor sit amet, dolor gravida placerat liberolorem ipsum dolor consectetur adipiscing elit, sed do eiusmod.')); ?></p>-->
                        <!--<p class="p-check text-white"><?php echo e(__('More programs activities, sed diam nonummy nibh euismod. Lorem ipsum dolor sit amet.')); ?></p>-->
                        <!--<p class="p-check text-white"><?php echo e(__('messages.More benefit nonummy nibh euismod. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.')); ?></p>-->
                        <div class="spacer-90"></div>
                    </div>
                    <div class="col-sm-12 col-md-12 col-lg-5">
                        <img src="<?php echo e(asset('images/newteacherss.png')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <!-- OUR GALLERY -->
    <div class="">
        <div class="content-wrap">
            <div class="container">

                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <p class="supheading text-center"><?php echo e(__('messages.Our Gallery')); ?></p>
                        <h2 class="section-heading text-center mb-5">
                            <?php echo e(__('messages.Moment from Fitkid')); ?>

                        </h2>
                    </div>
                </div>
                
                <div class="row popup-gallery gutter-5">
                    <?php if($gallery): ?>
                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Item <?php echo e($key); ?> -->
                    <div class="col-xs-12 col-md-6 col-lg-4">
                        <div class="box-gallery">
                            <a href="<?php echo e(asset('admin-assets/gallery').'/'.$values->image); ?>" title="Gallery #<?php echo e($key); ?>">
                                <img src="<?php echo e(asset('admin-assets/gallery').'/'.$values->image); ?>" alt="" class="img-fluid">
                                <div class="project-info">
                                    <div class="project-icon">
                                        <span class="fa fa-search"></span>
                                    </div>
                                </div>
                            </a>

                        </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  
                  
                    
                </div>
                  <div class="spacer-30"></div>
                  <a href="<?php echo e(url('/gallery')); ?>" class="btn btn-secondary" style="margin:0 auto; display: table; "><?php echo e(__('messages.VIEW MORE')); ?></a>
            </div>
        </div>
    </div>

    <!-- OUR VIDEO -->
    <div class="">
        <div class="content-wrap">
            <div class="container">

                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <p class="supheading text-center"><?php echo e(__('messages.Videos')); ?></p>
                        <h2 class="section-heading text-center mb-5">
                            <?php echo e(__('messages.Moment from Fitkid')); ?>

                        </h2>
                    </div>
                </div>
                
                <div class="row popup-gallery gutter-5">
                    <?php if($video): ?>
                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$valuess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Item <?php echo e($key); ?> -->
                    <div class="col-xs-12 col-md-6 col-lg-4">
                        <div class="box-gallery">
                           <iframe width="560" height="315" src="<?php echo e($valuess->link); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>

                        </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  
                  
                    
                </div>
                  <div class="spacer-30"></div>
                  <a href="<?php echo e(url('/gallery')); ?>" class="btn btn-secondary" style="margin:0 auto; display: table; "><?php echo e(__('messages.VIEW MORE')); ?></a>
            </div>
        </div>
    </div>

    <!-- OUR TESTIMONIALS -->
    <div class="section">
        <div class="content-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <p class="supheading text-center"><?php echo e(__('messages.Our Testimonials')); ?></p>
                        <h2 class="section-heading text-center mb-5">
                            <?php echo e(__('messages.What Parents say')); ?>

                        </h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 col-md-10 offset-md-1">
                        <div class="text-center text-secondary mb-3"><i class="fa fa-quote-right fa-3x"></i></div>
                        <div id="testimonial" class="owl-carousel owl-theme">
                            <?php if($testi): ?>
                            <?php $__currentLoopData = $testi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="rs-box-testimony">
                                    <div class="quote-box">
                                        <blockquote>
                                        <?php echo e($testimonial->description); ?>

                                        </blockquote>
                                      <!--   <div class="media">
                                            <img src="<?php echo e(asset('images/team-img1.jpg')); ?>" alt="" class="rounded-circle">
                                        </div> -->
                                        <p class="quote-name">
                                             <?php echo e($testimonial->name); ?> <span> <?php echo e($testimonial->designation); ?></span>
                                        </p>                        
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
 
 var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
        }
 };
 
 var Status = getUrlParameter("Status");
 var PaymentToken = getUrlParameter("PaymentToken");
 var PaymentId = getUrlParameter("PaymentId");
 var PaidOn = getUrlParameter("PaidOn");
 var orderReferenceNumber = getUrlParameter("orderReferenceNumber");
 
 if(typeof Status !== 'undefined'  && typeof PaymentToken !== 'undefined' &&
    typeof PaymentId !== 'undefined' && typeof PaidOn !== 'undefined' && typeof orderReferenceNumber !== 'undefined'){
     var _token = "<?php echo e(csrf_token()); ?>";
      var data ={_token:_token, Status : Status,PaymentToken : PaymentToken, PaymentId : PaymentId, PaidOn : PaidOn, orderReferenceNumber : orderReferenceNumber};  
      data = new FormData();
      data.append("_token",_token);
      data.append("Status",Status);
      data.append("PaymentToken",PaymentToken);
      data.append("PaymentId",PaymentId);
      data.append("PaidOn",PaidOn);
      data.append("orderReferenceNumber",orderReferenceNumber);
       $.ajax({
              url :"<?php echo e(env('APP_URL')); ?>payment_status",
              type : "POST",
              data : data,           
              cache: false,             
              processData: false,
              contentType: false, 
              dataType: "json",
              success: function(response) 
              {
                if(response.result == true)
                {
                    toastr.success(response.message);
                }else{
                    toastr.info(response.message);
                }
                window.location.href="<?php echo e(url('')); ?>";
              },
              error: function(response)
              {
                    toastr.error(JSON.stringify(response));
              }       
            });
      
       

    }
  
 

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fitkids/public_html/resources/views/index.blade.php ENDPATH**/ ?>