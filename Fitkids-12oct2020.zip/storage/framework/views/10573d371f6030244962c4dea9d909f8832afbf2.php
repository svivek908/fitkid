<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  
   <!-- BANNER -->
    <div class="section banner-page" data-background="<?php echo e(asset('images/banner-single.jpg')); ?>">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page"><?php echo e(__('messages.Gallery')); ?></div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('messages.Home')); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.Gallery')); ?></li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>

    <!-- OUR GALLERY -->
    <div class="">
        <div class="content-wrap">
            <div class="container">
                <h1><?php echo e(__('messages.Photos')); ?></h1>
                <div class="row popup-gallery gutter-5">
                    <?php if($gallery): ?>
                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$gallery_imgs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Item <?php echo e($key); ?> -->
                    <div class="col-xs-12 col-md-6 col-lg-4">
                        <div class="box-gallery">
                            <a href="<?php echo e(asset('admin-assets/gallery').'/'.$gallery_imgs->image); ?>" title="Gallery #<?php echo e($key); ?>">
                                <img src="<?php echo e(asset('admin-assets/gallery').'/'.$gallery_imgs->image); ?>" alt="" class="img-fluid">
                                <div class="project-info">
                                    <div class="project-icon">
                                        <span class="fa fa-search"></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                
                
                
             
                </div>
                
            </div>
            <div class="container">
                <h1><?php echo e(__('messages.Videos')); ?></h1>
                <div class="row popup-gallery gutter-5">
                    <?php if($video): ?>
                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$videos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Item <?php echo e($key); ?> -->
                    <div class="col-xs-12 col-md-6 col-lg-4">
                        <div class="box-gallery">
                               
                           <iframe width="560" height="315" src="<?php echo e($videos->link); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                
                
                
             
                </div>
                
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laabhomc/public_html/sahiapp.com/fitkid.com/resources/views/gallery.blade.php ENDPATH**/ ?>