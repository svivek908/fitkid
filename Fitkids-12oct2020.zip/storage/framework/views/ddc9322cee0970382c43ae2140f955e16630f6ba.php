<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->


    <!-- CONTENT -->
     <div class="container-fluid"> 
      <!-- Title -->
      <div class="row heading-bg">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <h5 class="txt-dark" style="float: left;">Students</h5>
          
        </div>
      </div>
     
      <br>
      <div class="row">
        <div class="col-xs-12">
          <div class="panel panel-default card-view">
            <div class="panel-wrapper collapse in">
              <div class="datatable-responsive table-responsive">
                <table id="simpletable" class="table  table-bordered nowrap dark">
                  <thead>
                    <tr>
                      <th>Student ID</th>
                      <th>Course name</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Gender</th>
                      <th>Address</th>
                      <th>Education</th>
                 
                    <!--   <th>Status</th> -->
                     <!--  <th>Action</th> -->
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(isset($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr >
                      <td><?php echo e($pro->id); ?></td>
                      <td><?php echo e($pro->cname); ?></td>
                      <td><?php echo e($pro->name); ?></td>
                      <td><?php echo e($pro->email); ?></td>
                      <td><?php echo e($pro->mobile); ?></td>
                      <td><?php echo e($pro->gender); ?></td>
                      <td><?php echo e($pro->address); ?></td>
                      <td><?php echo e($pro->education); ?></td>
                     
                     <!--  <td>
                        <select class="form-control" id="order_status" data-id="<?php echo e($pro->id); ?>">
                          <option <?php echo e($pro->status == 'pending' ? 'selected'  : ''); ?> value='pending'>Pending</option>
                          <option <?php echo e($pro->status == 'approved' ? 'selected'  : ''); ?> value='approved'>Approved</option>
                          <option <?php echo e($pro->status == 'blocked' ? 'selected'  : ''); ?> value='blocked'>Blocked</option>
                          <option <?php echo e($pro->status == 'disable' ? 'selected'  : ''); ?> value='disabled'>Disabled</option>
                        </select>

                      </td> -->
                    <!--   <td class="text-center"><a class="text-inverse" title="View student" data-toggle="tooltip" data-original-title="view student "><i class="fa fa-eye font-18 txt-primary data-table-edit" data-id="<?php echo $pro->id;; ?>" data-editurl="<?php echo e(url('admin/view-student')); ?>" style="cursor: pointer;"></i></a></td> -->
                     </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                  </tbody>
                  <tfoot>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /Row --> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projects\fitkid.com\resources\views/admin/view-batch.blade.php ENDPATH**/ ?>