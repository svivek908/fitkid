<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  <style type="text/css">
      @media (min-width: 768px)
      {
        a.btn.btn-secondary
        {
            margin-left: 25%;
        }
      }
      .help-block.with-errors p {
    color: red;
      }
      .form-label
      {
    color: #000;
    font-weight: 600;
      }
  </style>

 <div id="contact">
        <div class="content-wrap pb-0">
           <div class="section banner-page" data-background="<?php echo e(asset('images/courcess.png')); ?>">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page"><?php echo e(__('messages.Update Profile')); ?></div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('messages.Home')); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.Update Profile')); ?></li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12">
                        
                        <?php if(session()->has('message')): ?>
                                       <div class="alert alert-success">
                                           <?php echo e(session()->get('message')); ?>

                                       </div>
                             <?php elseif(session()->has('emessage')): ?>
                                       <div class="alert alert-danger">
                                           <?php echo e(session()->get('emessage')); ?>

                                       </div>
                             <?php endif; ?>
                        <form class="form-contact" action="<?php echo e(route('update_user')); ?>" method="POST">
                           <?php echo csrf_field(); ?>
                            <div class="row">
                             
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <label class="form-label"><?php echo e(__('messages.Name')); ?></label>
                                        <input type="text" class="form-control" id="name" placeholder="<?php echo e(__('messages.Enter student name')); ?>" required=""  name="name" value="<?php echo e($users->name); ?>">
                                        <input type="hidden" class="form-control" name="id" value="<?php echo e($users->id); ?>">
                                    
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('name')): ?>
                                              <p><?php echo e($errors->first('name')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label"><?php echo e(__('messages.Email')); ?></label>
                                        <input type="email" class="form-control" id="email" placeholder="<?php echo e(__('messages.Enter student email')); ?>" required=""  name="email" value="<?php echo e($users->email); ?>" disabled="">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('email')): ?>
                                              <p><?php echo e($errors->first('email')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                       <label class="form-label"><?php echo e(__('messages.Mobile')); ?></label>
                                        <input type="number" class="form-control" id="mobile" placeholder="<?php echo e(__('messages.Enter your mobile number')); ?>`" required=""  name="mobile" value="<?php echo e($users->mobile); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('mobile')): ?>
                                              <p><?php echo e($errors->first('mobile')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            

                                 <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label"><?php echo e(__('messages.Education')); ?></label>
                                        <input type="text" class="form-control" id="education" placeholder="<?php echo e(__('messages.education')); ?>" name="education" required="" value="<?php echo e($users->education); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('education')): ?>
                                              <p><?php echo e($errors->first('education')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group" >
                                      <label class="form-label" style="float: left;width: 100%;padding-bottom: 10px;"><?php echo e(__('messages.Gender')); ?></label>
                                        <input type="radio" class="" name="gender" value="Male" <?php if($users->gender == 'Male'): ?><?php echo e('checked'); ?><?php endif; ?>><?php echo e(__('messages.Male')); ?>

                                        <input type="radio" class="" name="gender" value="FeMale" <?php if($users->gender == 'FeMale'): ?><?php echo e('checked'); ?><?php endif; ?>><?php echo e(__('messages.Female')); ?>

                                        <div class="help-block with-errors">
                                              <?php if($errors->has('gender')): ?>
                                              <p><?php echo e($errors->first('gender')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>


                                 

                               <div class="col-sm-12 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label"><?php echo e(__('messages.Address')); ?></label>
                                        <textarea  class="form-control" id="address" placeholder="<?php echo e(__('messages.Enter student address')); ?>" required=""  name="address" value=""><?php echo e($users->address); ?></textarea>
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('address')): ?>
                                              <p><?php echo e($errors->first('address')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            

                            </div>
                            
                            <div class="form-group">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-primary disabled" style="pointer-events: all; cursor: pointer;"><?php echo e(__('messages.Update')); ?></button>
                            </div>
                        </form>
                        <div class="spacer-content"></div>

                    </div>
                    
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<style>
  .content-wrap {
    padding-bottom: 80px!important; 
    margin-bottom: 80px;
}
.pb-0, .py-0
{
  padding: unset!important;
}
.pb-5, .py-5 {
    padding-bottom: 3rem!important;
    margin-bottom: 0;
}
.spacer-content {
    display: none;
}
</style>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fitkids/public_html/resources/views/edit_profile.blade.php ENDPATH**/ ?>