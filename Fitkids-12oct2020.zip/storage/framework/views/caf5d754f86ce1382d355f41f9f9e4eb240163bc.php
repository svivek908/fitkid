<?php $__env->startSection('content'); ?>



    <!-- CONTENT -->   
<?php if(count($course_details)): ?>
    <div class="section ">
        <div class="content-wrap ii">

        <div class="content-wrap pb-0">
          <div class="section banner-page" data-background="http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg" style="background-image: url(&quot;http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg&quot;);">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page"><?php echo e($course_details[0]->name); ?></div>
               </div>
        </div>
    </div>
  </div>

            <div class="container">
                <div class="row">
                    
                    <div class="col-sm-12 col-md-12 col-lg-6">
                        <div class="single-news">
                            <img src="<?php echo e(asset('admin-assets/course').'/'.$course_details[0]->image); ?>" alt="" class="img-fluid rounded"> 
                            <div class="spacer-30"></div>

                            <h2 class="title"> Course Description </h2> 
                          
                            <div class="spacer-30"></div>

                            <p><?php echo e($course_details[0]->description); ?></p>
                            <div class="spacer-50"></div>
                      

                        </div>
                    </div>
                    
                    <div class="col-sm-12 col-md-12 col-lg-6">
                        <div class="events-widget">
                           

                            <div class="widget-title">Detail</div>
                            <dl>
                                <dt>Course name:</dt>
                                <dd><?php echo e($course_details[0]->name); ?></dd>
                                <dt>Fees:</dt>
                                <dd><?php echo e($course_details[0]->fees); ?>&nbsp;SAR</dd>
                                <dt>Age:</dt>
                                <dd><?php echo e($course_details[0]->age_from); ?> - <?php echo e($course_details[0]->age_to); ?> years</dd>
                                <dt>Class Strength:</dt>
                                <dd><?php echo e($course_details[0]->class_size); ?></dd>
                                <dt>Started From:</dt>
                                <dd><?php echo e($course_details[0]->start_date); ?></dd>
                                <dt>End date:</dt>
                                <dd><?php echo e($course_details[0]->end_date); ?></dd>
                                <dt>Remaining days:</dt>
                                <?php $get_day=strtotime($course_details[0]->end_date)-strtotime(date("Y-m-d")); ?>
                                <dd><?php echo e(round($get_day / (60 * 60 * 24))); ?> </dd>
                            </dl>
              <a class="btn btn-primary btn-block block-btn bb" href="<?php echo e(asset('admin-assets/course/document').'/'.$course_details[0]->document); ?>" download="" style="width: auto;margin: auto;">&nbsp;Download Document</a>

                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
    </div>
        <?php else: ?>
     <div class="section ">
        <div class="content-wrap ii" style="padding: 0 !important;margin: 0 !important;">
         <div class="content-wrap pb-0" style="padding: 0 !important;margin: 0 !important;">
             <div class="section banner-page" data-background="http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg" style="background-image: url(&quot;http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg&quot;);">
            <div class="content-wrap pos-relative">
                <div class="d-flex justify-content-center bd-highlight mb-3">
                    <div class="title-page">My Courses</div>
                   </div>
               </div>
            </div>
         </div>

         <div class="container">
           
            <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
            <div class="title-page"><h2>OOPS! Currently you don't have any course available</h2></div>
            </div>
              <a class="btn btn-primary btn-block block-btn bb" href="<?php echo e(url('/courses')); ?>" style="width: 25%;margin: auto;">&nbsp;Buy a course</a>
        </div>
             

        
         </div>

        </div>
    </div>
       <?php endif; ?>     
 <?php $__env->stopSection(); ?>    

<style>
    dt {
    font-weight: 700;
    float: left;
    margin-right: 10px;
}
dd
{
    text-align: right;
}
.img-fluid
{
    width: 100%;
}
  .content-wrap {
    padding-bottom: 80px!important; 
    margin-bottom: 0px;
   
}
.pb-0, .py-0
{
  padding: unset!important;
}
.banner-page .content-wrap {
    padding: 70px 0;
    padding-top: 60px!important;
}
.pb-5, .py-5 {
    padding-bottom: 3rem!important;
    margin-bottom: 0;
}
.ii
{
    margin-bottom: 0
}
</style>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fitkid.com\resources\views/my_courses.blade.php ENDPATH**/ ?>