<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  <style type="text/css">
    .content-wrap {
    padding: 80px 0;
    margin-bottom: 0;
}
      @media (min-width: 768px)
      {
        a.btn.btn-secondary
        {
            margin-left: 25%;
        }
      }
      .help-block.with-errors p {
    color: red;
      }
      .form-label
      {
    color: #000;
    font-weight: 600;
      }
      .form-group a {
    color: #fd4d40;
}
form.form-contact {
    margin-top: 5%;
}

.bg {
    float: left;
    width: 100%;
    background-color: #f8f8f8;
    padding: 50px;
    margin-bottom: 20px;
}
  </style>

 <div id="contact">
        <div class="content-wrap pb-0" style="">
<div class="section banner-page" data-background="http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg" style="background-image: url(&quot;http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg&quot;);">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page"><?php echo e(__('messages.Register')); ?></div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('messages.Home')); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.register')); ?></li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>
  </div>
            <div class="container" style="margin-top:30px;">

                <div class="row">
                    <div class="col-12 col-md-5">
                      
                        <img src="<?php echo e(asset('images/kid.jpg')); ?>" style="width: 100%;">
                        <?php if(session()->has('message')): ?>
                                       <div class="alert alert-success">
                                           <?php echo e(session()->get('message')); ?>

                                       </div>
                             <?php elseif(session()->has('emessage')): ?>
                                       <div class="alert alert-danger">
                                           <?php echo e(session()->get('emessage')); ?>

                                       </div>
                             <?php endif; ?>
                           </div>
                           <div class="col-12 col-md-7">
                              <!-- <h2 class="section-heading text-center mb-5" style="text-align: left!important;"> -->
                         
                         <div class="bg">
                             
                        <form class="form-contact" action="<?php echo e(route('create')); ?>" method="POST">
                           <?php echo csrf_field(); ?>
                            <div class="row">
                           
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <label class="form-label"><?php echo e(__('messages.Name')); ?></label>
                                        <input type="text" class="form-control" id="name" placeholder="<?php echo e(__('messages.Enter student name')); ?>" required=""  name="name" value="<?php echo e(old('name')); ?>">
                                    
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('name')): ?>
                                              <p><?php echo e($errors->first('name')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label"><?php echo e(__('messages.Email')); ?></label>
                                        <input type="email" class="form-control" id="email" placeholder="<?php echo e(__('messages.Enter student email')); ?>" required=""  name="email" value="<?php echo e(old('email')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('email')): ?>
                                              <p><?php echo e($errors->first('email')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                       <label class="form-label"><?php echo e(__('messages.Mobile')); ?></label>
                                        <input type="number" class="form-control" id="mobile" placeholder="<?php echo e(__('messages.Enter your mobile number')); ?>" required=""  name="mobile" value="<?php echo e(old('mobile')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('mobile')): ?>
                                              <p><?php echo e($errors->first('mobile')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                            

                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label"><?php echo e(__('messages.Password')); ?></label>
                                        <input type="password" class="form-control" id="password" placeholder="<?php echo e(__('messages.Password')); ?>" name="password" required="" value="<?php echo e(old('password')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('password')): ?>
                                              <p><?php echo e($errors->first('password')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label" style="float: left;width: 100%; margin-bottom: 15px;"><?php echo e(__('messages.Gender')); ?></label>
                                        <input type="radio" class="" name="gender" value="Male" checked=""><?php echo e(__('messages.Male')); ?>

                                        <input type="radio" class="" name="gender" value="FeMale" style="margin-left: 10px"><?php echo e(__('messages.Female')); ?>

                                        <div class="help-block with-errors">
                                              <?php if($errors->has('gender')): ?>
                                              <p><?php echo e($errors->first('gender')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                 <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label"><?php echo e(__('messages.Education')); ?></label>
                                        <input type="text" class="form-control" id="education" placeholder="<?php echo e(__('messages.education')); ?>" name="education" required="" value="<?php echo e(old('education')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('education')): ?>
                                              <p><?php echo e($errors->first('education')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                 

                               <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                      <label class="form-label"><?php echo e(__('messages.Address')); ?></label>
                                        <textarea  class="form-control" id="address" placeholder="<?php echo e(__('messages.Enter student address')); ?>" required=""  name="address" value=""><?php echo e(old('address')); ?></textarea>
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('address')): ?>
                                              <p><?php echo e($errors->first('address')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                             <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                    <input type="checkbox" style="float: left;
    margin-top: 5px;" required="" name="privacy_policy" value="1"> <p style="float:left;">By signing up you agree to our  <a href="<?php echo e(url('privacy_policy')); ?>" >  Privacy Policy</a> and  <a href="<?php echo e(url('terms')); ?>" >Terms & Conditions</a></p>
        <div class="help-block with-errors">
                                              <?php if($errors->has('privacy_policy')): ?>
                                              <p><?php echo e($errors->first('privacy_policy')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                               <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                      <p><?php echo e(__('messages.Already have an account ??')); ?> <a href="<?php echo e(url('user_login')); ?>"><?php echo e(__('messages.Sign in')); ?></a></p>
                                    </div>
                                </div>

                            </div>
                            
                            <div class="form-group">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-primary disabled" style="pointer-events: all; cursor: pointer;"><?php echo e(__('messages.Register')); ?></button>
                            </div>
                        </form>

                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<style>
  .content-wrap {
    padding-bottom: 80px!important; 
    margin-bottom: 80px;
}
.pb-0, .py-0
{
  padding: unset!important;
}
.form-label {
    color: #000;
    font-weight: 600;
    display: none;
}
input[type=checkbox], input[type=radio] {
    box-sizing: border-box;
    padding: 0;
    padding-right: 12px;
    margin-right: 5px;
    margin-top: 15px;
    padding-top: 9px;
}
</style>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laabhlz4/public_html/fitkid.com/resources/views/register.blade.php ENDPATH**/ ?>