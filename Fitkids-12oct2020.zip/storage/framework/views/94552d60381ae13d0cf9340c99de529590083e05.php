 
  <?php $__env->startSection('content'); ?>
  <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
                 <?php echo e(session()->get('message')); ?>

             </div>            
  <?php endif; ?>
    <div class="container-fluid"> 
      <!-- Title -->
      <div class="row heading-bg">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <h5 class="txt-dark" style="float: left;">Students</h5>
          
        </div>
      </div>
     
      <br>
      <div class="row">
        <div class="col-xs-12">
          <div class="panel panel-default card-view">
            <div class="panel-wrapper collapse in">
              <div class="datatable-responsive table-responsive">
                <table id="simpletable" class="table  table-bordered nowrap dark">
                  <thead>
                    <tr>
                      <th>Student ID</th>
                      <th>Course ID</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Gender</th>
                      <th>Address</th>
                      <th>Education</th>
                   <!--    <th>Created Date</th> -->
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(isset($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr >
                      <td><?php echo e($pro->id); ?></td>
                      <td><?php if($pro->course_id > 0): ?><?php echo e($pro->course_id); ?> <?php else: ?> <?php echo e('-'); ?> <?php endif; ?></td>
                      <td><?php echo e($pro->name); ?></td>
                      <td><?php echo e($pro->email); ?></td>
                      <td><?php echo e($pro->mobile); ?></td>
                      <td><?php echo e($pro->gender); ?></td>
                      <td><?php echo e($pro->address); ?></td>
                      <td><?php echo e($pro->education); ?></td>
                     <!--  <td><?php echo e($pro->created_at); ?></td> -->
                      <td>
                        <select class="form-control" id="order_status" data-id="<?php echo e($pro->id); ?>">
                          <option <?php echo e($pro->status == 'pending' ? 'selected'  : ''); ?> value='pending'>Pending</option>
                          <option <?php echo e($pro->status == 'approved' ? 'selected'  : ''); ?> value='approved'>Approved</option>
                          <option <?php echo e($pro->status == 'blocked' ? 'selected'  : ''); ?> value='blocked'>Blocked</option>
                          <option <?php echo e($pro->status == 'disable' ? 'selected'  : ''); ?> value='disabled'>Disabled</option>
                        </select>

                      </td>
                      <td class="text-center"><a class="text-inverse" title="View student" data-toggle="tooltip" data-original-title="view student "><i class="fa fa-eye font-18 txt-primary data-table-edit" data-id="<?php echo $pro->id;; ?>" data-editurl="<?php echo e(url('admin/view-student')); ?>" style="cursor: pointer;"></i></a></td>
                     </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                  </tbody>
                  <tfoot>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /Row --> 
    </div>
    <?php $__env->stopSection(); ?>
  <?php $__env->startSection('script'); ?>
  <script type="text/javascript">
       $(document).ready(function() {

         $('body').on('change','#order_status',function()
          {
            var mid = $(this).attr('data-id');
            var cid = $(this).val();
            $.ajax({
              url:"<?php echo e(url('admin/change_student_status')); ?>?m_id="+mid+"&c_id="+cid,
              type: "GET",
              dataType: "html",
              success: function(response) 
              {
                  if(response.result == true)
                  {
                    location.reload();
                  }
              },
              error: function(response)
              {
                console.log(response);
              }       
            });
         });  });
  </script>
  <?php $__env->stopSection(); ?>
  <style >
    .heading-bg {
    height: 45px;
    margin: 0 -20px 10px;
    padding: 13px 0 0;
    margin-bottom: -9px!important;
}
  </style>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laabhomc/public_html/sahiapp.com/fitkid.com/resources/views/admin/students.blade.php ENDPATH**/ ?>