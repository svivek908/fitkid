<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  <style type="text/css">

    .form-group a {
    color: #fd4d40;
}
.pb-5, .py-5 {
    padding-bottom: 3rem!important;
    margin-bottom: 0;
}
      @media (min-width: 768px)
      {
        a.btn.btn-secondary
        {
            margin-left: 25%;
        }
      }
      .help-block.with-errors p {
    color: red;
}
  </style>

 <div id="contact">
        <div class="content-wrap pb-0">
          <div class="section banner-page" data-background="http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg" style="background-image: url(&quot;http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg&quot;);">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page">Login</div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Login</li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>
  </div>
            <div class="container">
                <div class="row">
                        <div class="col-12 col-md-6">
                            <img src="<?php echo e(asset('images/kid.png')); ?>" style="width: 55%;margin-top: -20px">
                        </div>
                    <div class="col-12 col-md-6">
                       <!--  <h2 class="section-heading text-center mb-5" style="text-align: left!important;">
                            Login
                        </h2> -->
                           <?php if(session()->has('message')): ?>
                                       <div class="alert alert-success">
                                           <?php echo e(session()->get('message')); ?>

                                       </div>
                             <?php elseif(session()->has('emessage')): ?>
                                       <div class="alert alert-danger">
                                           <?php echo e(session()->get('emessage')); ?>

                                       </div>
                             <?php endif; ?>
                        <form class="form-contact" action="<?php echo e(route('user_auth')); ?>" method="POST" id="loginform123">
                           <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="email" placeholder="Email Address" required=""  name="email" value="<?php echo e(old('email')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('email')): ?>
                                              <p><?php echo e($errors->first('email')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <input type="password" class="form-control" id="password" placeholder="Password" name="password" required="" value="<?php echo e(old('password')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('password')): ?>
                                              <p><?php echo e($errors->first('password')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                               <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                      <p style="float: left;" class="yy">Don't have an account ?? <a href="<?php echo e(url('user_register')); ?>" >Register here</a></p>
                                      <p ><a class="forgot-link" href="<?php echo e(url('/forgot_password')); ?>">Forgot your password?</a></p>
                                    </div>
                                </div>

                            </div>
                            
                            <div class="form-group">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-primary disabled btn4" style="pointer-events: all; cursor: pointer;">Login</button>
                            </div>
                        </form>
                        <div class="spacer-content"></div>

                    </div>
                    
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<style>
  .content-wrap {
    padding-bottom: 80px!important; 
    margin-bottom: 80px;
}
.pb-0, .py-0
{
  padding: unset!important;
}
</style>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fitkid.com\resources\views/login.blade.php ENDPATH**/ ?>