 
  <?php $__env->startSection('content'); ?>
  <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
                 <?php echo e(session()->get('message')); ?>

             </div>            
  <?php endif; ?>
    <div class="container-fluid"> 
      <!-- Title -->
      <div class="row heading-bg">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <h5 class="txt-dark" style="float: left;">Payment</h5>
          
        </div>
      </div>
     
      <br>
      <div class="row">
        <div class="col-xs-12">
          <div class="panel panel-default card-view">
            <div class="panel-wrapper collapse in">
              <div class="datatable-responsive table-responsive">
                <table id="simpletable" class="table  table-bordered nowrap dark">
                  <thead>
                    <tr>
                      <th>Sr No</th>
                      <th>Student ID</th>
                      <th>Course ID</th>
                      <th>Price</th>
                      <th>Payment ID</th>
                      <th>Status</th>
                      <th>Payment Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(isset($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr >
                      <td><?php echo e(++$k); ?></td>
                      <td><?php echo e($pro->login_id); ?></td>
                      <td><?php echo e($pro->course_id); ?></td>
                      <td><?php echo e($pro->price); ?></td>
                      <td><?php echo e($pro->payment_id); ?></td>
                      <td><?php echo e($pro->status); ?></td>
                      <td><?php echo e($pro->created_at); ?></td>
                     </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                  </tbody>
                  <tfoot>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /Row --> 
    </div>
    <?php $__env->stopSection(); ?>
  <?php $__env->startSection('script'); ?>
  <script type="text/javascript">
       $(document).ready(function() {

         $('body').on('change','#order_status',function()
          {
            var mid = $(this).attr('data-id');
            var cid = $(this).val();
            $.ajax({
              url:"<?php echo e(url('admin/change_student_status')); ?>?m_id="+mid+"&c_id="+cid,
              type: "GET",
              dataType: "html",
              success: function(response) 
              {
                  if(response.result == true)
                  {
                    location.reload();
                  }
              },
              error: function(response)
              {
                console.log(response);
              }       
            });
         });  });
  </script>
  <?php $__env->stopSection(); ?>
  <style >
    .heading-bg {
    height: 45px;
    margin: 0 -20px 10px;
    padding: 13px 0 0;
    margin-bottom: -9px!important;
}
  </style>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fitkids/public_html/resources/views/admin/payments.blade.php ENDPATH**/ ?>