  <?php 
   use App\Http\Controllers\HomeController;
        $user = HomeController::get_user();
        ?>
    <style type="text/css">
        a.active {
    color: #ffffff !important;
    background-color: #FD4D40 !important;
}
a.nav-link.dropdown-toggle {
    border: 1px solid #fd4d40;
}
    </style>
    <!-- HEADER -->
    <div class="header header-1">

        <!-- TOPBAR -->
        <div class="topbar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-8 col-md-6">
                        <div class="info">
                            <div class="info-item">
                                <i class="fa fa-phone"></i> +971 12 345 6789
                            </div>
                            <div class="info-item">
                                <i class="fa fa-envelope-o"></i> <a href="mailto:info@fitkid.com" title="">info@fitkid.com</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 col-md-6">
                        <div class="sosmed-icon pull-right d-inline-flex">
                            <a href="https://www.facebook.com/" class="fb" target="_blank"><i class="fa fa-facebook" ></i></a> 
                            <a href="https://www.twitter.com/" class="tw" target="_blank"><i class="fa fa-twitter" target="_blank"></i></a> 
                            <a href="https://www.instagram.com/" class="ig"><i class="fa fa-instagram"></i></a> 
                            <a href="https://www.linkedin.com/" class="in" target="_blank"><i class="fa fa-linkedin"></i></a> 
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- NAVBAR SECTION -->
        <div class="navbar-main">
            <div class="container">
                <nav id="navbar-example" class="navbar navbar-expand-lg">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul class="navbar-nav ml-auto">
                            <li class='nav-item <?php echo e(Request::segment(1) == "" ? "active" : ""); ?>'>
                                <a class="nav-link"  href="<?php echo e(url('/')); ?>">HOME</a>
                            </li>
                            <li class='nav-item <?php echo e(Request::segment(1) === "about" ? "active" : ""); ?>'>
                                <a class="nav-link" href="<?php echo e(url('/about')); ?>">ABOUT US</a>
                            </li>
                            <li class='nav-item <?php echo e(Request::segment(1) === "courses" ? "active" : ""); ?>'>
                                <a class="nav-link" href="<?php echo e(url('/courses')); ?>">COURSES</a>
                            </li>
                            <li class='nav-item <?php echo e(Request::segment(1) === "gallery" ? "active" : ""); ?>'>
                                <a class="nav-link" href="<?php echo e(url('/gallery')); ?>">GALLERY</a>
                            </li>
                           <li class='nav-item <?php echo e(Request::segment(1) === "contact" ? "active" : ""); ?>'>
                                <a class="nav-link" href="<?php echo e(url('/contact')); ?>">CONTACT US</a>
                            </li>
                            <?php if($user): ?>
                            <li class='nav-item dropdown dmenu <?php echo e(Request::segment(1) === "profile_manage" ? "active" : ""); ?>'>
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="text-transform:uppercase;">
                                  <?php echo e($user->name); ?>

                                </a>
                                <div class="dropdown-menu">
                                   <a class="dropdown-item" href="<?php echo e(url('customer/profile_manage')); ?>">My Profile</a>
                                   <a class="dropdown-item" href="<?php echo e(url('customer/profile_course')); ?>">My Courses</a>
                                   <a class="dropdown-item" href="<?php echo e(url('customer/change_password')); ?>">Change Password</a>
                                   <a class="dropdown-item" href="<?php echo e(route('user-logout')); ?>">Logout</a>
                                </div>
                            </li>
                            <?php else: ?>
                            <li class='nav-item log'>

                                <a class='nav-link <?php if(Request::segment(1)=="user_register"): ?>  <?php echo e("active"); ?> <?php endif; ?>' style="padding: .5rem;margin: 0;" href="<?php echo e(url('/user_register')); ?>">REGISTER</a>

                                <a class='nav-link <?php echo e(Request::segment(1) === "user_login" ? "active" : ""); ?>' style="padding: .5rem;margin: 0;"  href="<?php echo e(url('/user_login')); ?>">LOGIN</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </nav> <!-- -->

            </div>
        </div>

    </div>
<style>
    @media (max-width: 767px)
    {
        .sosmed-icon.pull-right.d-inline-flex
        {
            margin-top: 11px;
            float: left;
        }
    }
</style><?php /**PATH D:\wamp64\www\Projects\fitkid.com\resources\views/header.blade.php ENDPATH**/ ?>