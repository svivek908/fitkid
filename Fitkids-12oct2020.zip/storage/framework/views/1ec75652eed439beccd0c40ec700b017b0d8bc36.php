<!-- <div class="fixed-sidebar-left">
    <ul class="nav navbar-nav side-nav nicescroll-bar">
      <li> <a href="<?php echo e(url('admin/dashboard')); ?>" data-toggle="collapse" data-target="#admin-dash">
        <div class="pull-left"><i class="mdi mdi-apps mr-20"></i><span class="right-nav-text">Dashboard</span></div>
        <div class="pull-right"></div>
        <div class="clearfix"></div>
        </a>
        
      </li>
     
      <li> <a href="<?php echo e(url('admin/trainee')); ?>" data-toggle="collapse" data-target="#admin-dash">
        <div class="pull-left"><i class="fa fa-users mr-20"></i><span class="right-nav-text">Students</span></div>
        <div class="pull-right"></div>
        <div class="clearfix"></div>
        </a>
        
      </li>
      <li> <a href="<?php echo e(url('admin/batch')); ?>" data-toggle="collapse" data-target="#admin-dash">
        <div class="pull-left"><i class="fa fa-database mr-20"></i><span class="right-nav-text">Batches</span></div>
        <div class="pull-right"></div>
        <div class="clearfix"></div>
        </a>
        
      </li>
     
      <li> <a href="javascript:void(0);" data-toggle="collapse" data-target="#icon_list">
        <div class="pull-left"><i class="mdi mdi-cube-outline mr-20"></i><span class="right-nav-text">Masters</span></div>
        <div class="pull-right"><i class="mdi mdi-chevron-down"></i></div>
        <div class="clearfix"></div>
        </a>
        <ul id="icon_list" class="collapse collapse-level-1">
          
          <li><a href="<?php echo e(url('admin/banner')); ?>">Banners</a></li>
          <li><a href="<?php echo e(url('admin/gallery')); ?>">Gallery</a></li>
          <li><a href="<?php echo e(url('admin/course')); ?>" translate="no">Courses</a></li>
          <li><a href="<?php echo e(url('admin/testimonial')); ?>" translate="no">Testimonial</a></li>
       
        </ul>
      </li>
     <li> <a href="<?php echo e(url('admin/admin_change_password')); ?>" data-toggle="collapse" data-target="#ui_element">
        <div class="pull-left"><i class="fa fa-unlock-alt mr-20"></i><span class="right-nav-text">Change Password</span></div>
        <div class="pull-right"></div>
        <div class="clearfix"></div>
        </a>
      </li>
     <li> <a href="<?php echo e(url('admin/edit_profile')); ?>" data-toggle="collapse" data-target="#ui_element">
        <div class="pull-left"><i class="fa fa-user mr-20"></i><span class="right-nav-text">Profile</span></div>
        <div class="pull-right"></div>
        <div class="clearfix"></div>
        </a>
      </li>

     <li> <a href="<?php echo e(route('admin-logout')); ?>" data-toggle="collapse" data-target="#ui_element">
        <div class="pull-left"><i class="fa fa-sign-out mr-20"></i><span class="right-nav-text">Logout</span></div>
        <div class="pull-right"></div>
        <div class="clearfix"></div>
        </a>
      </li>
    </ul>
  </div> --><?php /**PATH /home/laabhlz4/public_html/fitkid.com/resources/views/admin/sidebar.blade.php ENDPATH**/ ?>