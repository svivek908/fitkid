<footer class="footer container-fluid pt-10 pb-10  pl-30 pr-30">
      <div class="row">
        <div class="col-sm-12 ">
          <div class="pull-left text-dark pt-5 small">Copyright @ 2020  <b></b> All Rights Reserved.</div>
          <!-- <div class="pull-right">Design & Developed by :<a href="http://www.laabhaa.com/" target="_blank">Laabhaa Technologies</a></div> -->
          <div class="clearfix"></div>
        </div>
      </div>
    </footer><?php /**PATH /home/fitkids/public_html/resources/views/admin/footer.blade.php ENDPATH**/ ?>