
    <!-- CTA -->
    <div class="section bg-tertiary">
        <div class="content-wrap py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-sm-12 col-md-12">
                        <div class="cta-1">
                            <div class="body-text mb-3">
                                <h3 class="my-1 text-secondary"><?php echo e(__("messages.Let's join the best Karate now!")); ?></h3>
                                <p class="uk18 mb-0 text-white"><?php echo e(__('messages.We provide high standard Karate Training for your kids')); ?></p>
                            </div>
                            <div class="body-action">
                                <a href="<?php echo e(url('/contact')); ?>" class="btn btn-primary mt-3"><?php echo e(__('messages.CONTACT US')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- FOOTER SECTION -->
    <div class="footer" data-background="<?php echo e(asset('images/bg.jpg')); ?>">
        <div class="content-wrap">
            <div class="container">
                
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="footer-item">
                             <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo bottom" class="logo-bottom">
                        </a>
                            <div class="spacer-30"></div>
                             <div class="sosmed-icon d-inline-flex">
                               <a href="https://www.facebook.com/" class="fb" target="_blank"><i class="fa fa-facebook" ></i></a> 
                            <a href="https://www.twitter.com/" class="tw" target="_blank"><i class="fa fa-twitter" target="_blank"></i></a> 
                            <a href="https://www.instagram.com/" class="ig"><i class="fa fa-instagram"></i></a> 
                            <a href="https://www.linkedin.com/" class="in" target="_blank"><i class="fa fa-linkedin"></i></a> 
                            </div>
                           <!--  <a href="<?php echo e(url('/about')); ?>"><i class="fa fa-angle-right"></i> Read More</a> -->
                        </div>
                    </div>                  

                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="footer-item">
                            <div class="footer-title">
                               <?php echo e(__('messages.Contact Info')); ?>

                            </div>
                            <ul class="list-info">
                                <li>
                                    <div class="info-icon">
                                        <span class="fa fa-map-marker"></span>
                                    </div>
                                    <div class="info-text"><?php echo e(__('messages.123 Fitkid Streat, Fitkid Road. Soudi Arabia')); ?></div> </li>
                                <li>
                                    <div class="info-icon">
                                        <span class="fa fa-phone"></span>
                                    </div>
                                    <div class="info-text"><?php echo e(__('(971) 12-345-6789')); ?></div>
                                </li>
                                <li>
                                    <div class="info-icon">
                                        <span class="fa fa-envelope"></span>
                                    </div>
                                    <div class="info-text"><?php echo e(__('info@fitkid.com')); ?></div>
                                </li>
                                <li>
                                    <div class="info-icon">
                                        <span class="fa fa-clock-o"></span>
                                    </div>
                                    <div class="info-text"><?php echo e(__('Mon - Sat 09:00 - 17:00')); ?></div>
                                </li>
                            </ul>

                        </div>
                    </div>

                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="footer-item">
                            <div class="footer-title">
                                <?php echo e(__('messages.Useful Links')); ?>

                            </div>
                            
                            <ul class="list">
                                <li><a href="<?php echo e(url('/')); ?>" title="Home"><?php echo e(__('messages.Home')); ?></a></li>
                                <li><a href="<?php echo e(url('/about')); ?>" title="About us"><?php echo e(__('messages.About us')); ?></a></li>
                                <li><a href="<?php echo e(url('/courses')); ?>" title="Courses"><?php echo e(__('messages.Courses')); ?></a></li>
                                <li><a href="<?php echo e(url('/gallery')); ?>" title="Gallery"><?php echo e(__('messages.Gallery')); ?></a></li>
                              
                            </ul>
                                
                        </div>
                    </div>
                    
                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="footer-item">
                            <div class="footer-title">
                              <?php echo e(__('messages.More Information')); ?>

                            </div>
                          
                             <ul class="list">
                              <li><a href="<?php echo e(url('/contact')); ?>" title="Contact Us"><?php echo e(__('messages.Contact Us')); ?></a></li>
                                <li><a href="<?php echo e(url('/user_register')); ?>" title="Register"><?php echo e(__('messages.Register')); ?></a></li>
                                <li><a href="<?php echo e(url('/user_login')); ?>" title="Login"><?php echo e(__('messages.Login')); ?></a></li>
                                <li><a href="<?php echo e(url('/faq')); ?>" title="Faq"><?php echo e(__('messages.Faq')); ?></a></li>
                            </ul>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="fcopy">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <p class="ftex"><?php echo e(__('messages.Copyright')); ?> &copy; 2020, <?php echo e(__('messages.Fitkid All Rights Reserved.')); ?><span class="color-primary"></span>.  <span class="color-primary"></span></p> 
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <style>
        
    </style><?php /**PATH /home/laabhomc/public_html/sahiapp.com/fitkid.com/resources/views/footer.blade.php ENDPATH**/ ?>