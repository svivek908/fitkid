<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  
<!-- BANNER -->
    <div class="section banner-page" data-background="<?php echo e(asset('images/banner-single.jpg')); ?>">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page"><?php echo e(__('messages.Contact Us')); ?></div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('messages.Home')); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.Contact Us')); ?></li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>

    <!-- CONTACT -->
    <div id="contact">
        <div class="content-wrap pb-0">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12">
                        
                            <?php if(session()->has('message')): ?>
                                       <div class="alert alert-success">
                                           <?php echo e(session()->get('message')); ?>

                                       </div>
                             <?php elseif(session()->has('emessage')): ?>
                                       <div class="alert alert-danger">
                                           <?php echo e(session()->get('emessage')); ?>

                                       </div>
                             <?php endif; ?>
                        <form action="<?php echo e(url('add_contact')); ?>" class="form-contact" id="" data-toggle="validator" novalidate="true" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="p_name" placeholder="<?php echo e(__('messages.Enter Name')); ?>" required="" name="name">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="email" class="form-control" id="p_email" placeholder="<?php echo e(__('messages.Enter Email')); ?>" required="" name="email">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="p_subject" placeholder="<?php echo e(__('messages.Subject')); ?>" name="subject">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="p_phone" placeholder="<?php echo e(__('messages.Enter Phone Number')); ?>" name="mobile">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                 <textarea id="p_message" class="form-control" rows="6" placeholder="<?php echo e(__('messages.Enter Your Message')); ?>" name="message"></textarea>
                                <div class="help-block with-errors"></div>
                            </div>
                            <div class="form-group">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('messages.Send Message')); ?></button>
                            </div>
                        </form>
                        <div class="spacer-content"></div>

                    </div>
                    
                </div>
            </div>
        </div>
    </div>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d462565.1975944678!2d54.94755315007106!3d25.075085307174227!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f43496ad9c645%3A0xbde66e5084295162!2sDubai%20-%20United%20Arab%20Emirates!5e0!3m2!1sen!2sin!4v1584450927717!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    <!-- MAPS -->
<!--     <div class="maps-wraper">
        <div id="cd-zoom-in"></div>
        <div id="cd-zoom-out"></div>
        <div id="maps" class="maps" data-lat="-7.452278" data-lng="112.708992" data-marker="<?php echo e(asset('images/cd-icon-location.png')); ?>">
        </div>
    </div> -->
<style type="text/css">
    .help-block.with-errors {
    color: red;
}
</style>
   



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laabhomc/public_html/sahiapp.com/fitkid.com/resources/views/contact.blade.php ENDPATH**/ ?>