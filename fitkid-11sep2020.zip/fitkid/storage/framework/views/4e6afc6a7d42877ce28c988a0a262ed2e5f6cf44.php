<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->


    <!-- CONTENT -->
    <div class="section ">
        <div class="content-wrap ii">
               <div class="content-wrap pb-0">
          <div class="section banner-page" data-background="http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg" style="background-image: url(&quot;http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg&quot;);">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page"><?php echo e($course_details->name); ?></div>
            </div>
     <!--        <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Course Details</li>
                  </ol>
                </nav>
            </div> -->
        </div>
    </div>
  </div>
</div>
            <div class="container">
                <div class="row">
                    
                    <div class="col-sm-12 col-md-12 col-lg-6">
                        <div class="single-news">
                            <img src="<?php echo e(asset('admin-assets/course').'/'.$course_details->image); ?>" alt="" class="img-fluid rounded"> 
                            <div class="spacer-30"></div>

                            <h2 class="title"> Course Description </h2> 
                          
                            <div class="spacer-30"></div>

                            <p><?php echo e($course_details->description); ?></p>
                            <div class="spacer-50"></div>
                      

                        </div>
                    </div>
                    
                    <div class="col-sm-12 col-md-12 col-lg-6">
                        <div class="events-widget">
                           

                            <div class="widget-title">Detail</div>
                            <dl>
                                <dt>Course name:</dt>
                                <dd><?php echo e($course_details->name); ?></dd>
                                <dt>Fees:</dt>
                                <dd><?php echo e($course_details->fees); ?>&nbsp;SAR</dd>
                                <dt>Age:</dt>
                                <dd><?php echo e($course_details->age_from); ?> - <?php echo e($course_details->age_to); ?> years</dd>
                                <dt>Class Strength:</dt>
                                <dd><?php echo e($course_details->class_size); ?></dd>
                                <dt>Time:</dt>
                                <?php if(count($batch_details)): ?>
                                <?php $__currentLoopData = $batch_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <br/>
                                <div>
                                <input type="radio" name="batch_id" value="<?php echo e($b_det->id); ?>">
                                <span style="color: #000;margin-left:5px;"><?php echo e($b_det->open_time); ?> - <?php echo e($b_det->close_time); ?>

                                </span>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <dd>No batch available</dd>

                                <?php endif; ?>
                                
                            </dl>

                            <div class="spacer-30"></div>
                            <?php if(count($batch_details)): ?>
                            <a  class="btn btn-primary btn-block buy-button" data-toggle="modal" data-target="#myModal" style="width: 40%;float: left;">Print</a>
                            <a class="btn btn-primary btn-block buy-button" data-course_id='<?php echo e($course_details->id); ?>' data-price='<?php echo e($course_details->fees); ?>' style="width: 40%;float: left;">Buy now</a>
                            <?php endif; ?>
                            <div class="spacer-30"></div>
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
    </div>

<!-- Modal -->

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content" >
      <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body" id="DivIdToPrint">
        <h2 style="text-align: center;" class="modal-title">Course Details </h2>
           
<table style="width:100%">
  <tr>
    <th style="text-align: left;">Course name</th>
    <th colspan="2" style="text-align: right;"><?php echo e($course_details->name); ?></th>
  </tr>
  <tr>
    <th style="text-align: left;">Fees</th>
    <th colspan="2" style="text-align: right;"><?php echo e($course_details->fees); ?>&nbsp;SAR</th>
  </tr>
  <tr>
    <th style="text-align: left;">Age</th>
    <th colspan="2" style="text-align: right;"><?php echo e($course_details->age_from); ?> - <?php echo e($course_details->age_to); ?> years</th>
  </tr>
  <tr>
    <th style="text-align: left;">Class Strength</th>
    <th colspan="2" style="text-align: right;"><?php echo e($course_details->class_size); ?></th>
  </tr>
  <tr>
   </tr>
</table>
           
   <label style="text-align: left;font-weight: 700;font-size: 17px;">Description</label>
    <div><?php echo e($course_details->description); ?></div>
                   
</div>
      <div class="modal-footer">
           <input class="btn btn-primary btn-block buy-button" type='button' id='btn' value='Print' onclick='printDiv();'>
      </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php if(!count($batch_details)): ?>

<style type="text/css">
.buy-button{  
  color: currentColor;
  cursor: not-allowed;
  opacity: 0.5;
  text-decoration: none;
  }
</style>
<?php endif; ?>
<style>
    dt {
    font-weight: 700;
    float: left;
    margin-right: 10px;
}
dd
{
    text-align: right;
}
.img-fluid
{
    width: 100%;
}
  .content-wrap {
    padding-bottom: 80px!important; 
    margin-bottom: 0px;
   
}
.pb-0, .py-0
{
  padding: unset!important;
}
.banner-page .content-wrap {
    padding: 70px 0;
    padding-top: 60px!important;
}
.pb-5, .py-5 {
    padding-bottom: 3rem!important;
    margin-bottom: 0;
}
.content-wrap.ii {
    padding-top: 0;
}
</style>

<?php $__env->startSection('script'); ?>
  <script type="text/javascript">
       $(document).ready(function() {

         $('.buy-button').click(function()
          {
            var course_id = $(this).attr('data-course_id');
            var price = $(this).attr('data-price');
            $.ajax({
              url:"<?php echo e(url('customer/buy_detail')); ?>?c_id="+course_id+"&price="+price,
              type: "GET",
              dataType: "html",
              success: function(response) 
              {
                if(response.result == true)
                {
                  location.reload();
                }
              },
              error: function(response)
              {
                console.log(response);
              }       
            });
         });  

    }); 
     </script>
     <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fitkid.com\resources\views/course_details.blade.php ENDPATH**/ ?>