<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  <style type="text/css">
      @media (min-width: 768px)
      {
        a.btn.btn-secondary
        {
            margin-left: 25%;
        }
      }
      .help-block.with-errors p {
    color: red;
      }
      .form-label
      {
    color: #000;
    font-weight: 600;
      }
      .form-label {
    color: #000;
    font-weight: 600;
    display: none;
}
  </style>

 <div id="contact">
        <div class="content-wrap pb-0">
          <div class="section banner-page" data-background="http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg" style="background-image: url(&quot;http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg&quot;);">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page"><?php echo e(__('messages.Change Password')); ?></div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('messages.Home')); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.Change Password')); ?></li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-12">
                       
                        <?php if(session()->has('message')): ?>
                                       <div class="alert alert-success">
                                           <?php echo e(session()->get('message')); ?>

                                       </div>
                             <?php elseif(session()->has('emessage')): ?>
                                       <div class="alert alert-danger">
                                           <?php echo e(session()->get('emessage')); ?>

                                       </div>
                             <?php endif; ?>
                        <form class="form-contact" action="<?php echo e(route('update_password')); ?>" method="POST">
                           <?php echo csrf_field(); ?>
                            <div class="row">
                             
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <label class="form-label"><?php echo e(__('messages.Current Password')); ?></label>
                                        <input type="password" class="form-control" id="cpassword" placeholder="<?php echo e(__('messages.Enter your current password')); ?>" required=""  name="cpassword">
                                        
                                    
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('cpassword')): ?>
                                              <p><?php echo e($errors->first('cpassword')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label"><?php echo e(__('messages.New Password')); ?></label>
                                        <input type="password" class="form-control" id="password" placeholder="<?php echo e(__('messages.Enter password')); ?>" required=""  name="password">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('password')): ?>
                                              <p><?php echo e($errors->first('password')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                       <label class="form-label"><?php echo e(__('messages.Confirm Password')); ?></label>
                                        <input type="password" class="form-control" id="npassword" placeholder="<?php echo e(__('messages.Confirm your password')); ?>" required=""  name="npassword">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('npassword')): ?>
                                              <p><?php echo e($errors->first('npassword')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                               <div class="col-sm-6 col-md-6">
                                   <div class="form-group uu">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-primary disabled" style="pointer-events: all; cursor: pointer;"><?php echo e(__('messages.Update Password')); ?></button>
                            </div>
                            </div>

                            </div>
                            
                           
                        </form>
                        <div class="spacer-content"></div>

                    </div>
                    
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<style>
  .content-wrap {
    padding-bottom: 80px!important; 
    margin-bottom: 80px;
}
.pb-0, .py-0
{
  padding: unset!important;
}
.pb-5, .py-5 {
    padding-bottom: 3rem!important;
    margin-bottom: 0;
}
.spacer-content {
    display: none;
}

@media (max-width: 767px)
{
  
}
</style>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laabhomc/public_html/sahiapp.com/fitkid.com/resources/views/change_password.blade.php ENDPATH**/ ?>