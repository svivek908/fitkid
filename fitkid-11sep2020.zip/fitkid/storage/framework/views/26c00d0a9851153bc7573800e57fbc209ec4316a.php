<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
<style type="text/css">
    .single-news .title
    {
        font-size: 19px;
    }
    .title span {
    font-size: 14px;
}
dt {
    font-weight: 700;
    float: left;
    margin-right: 10px;
}
dd
{
    text-align: right;
}
.kk
{
    margin-top: 58px;
}
.single-news .title {
    font-size: 24px;
    font-weight: 700;
    color: #979ca2;
}

</style>
<div class="section banner-page" data-background="<?php echo e(asset('images/banner-single.jpg')); ?>" style="background-image: url(<?php echo e(asset('images/banner-single.jpg')); ?>)">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page">My Profile</div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">My Profile</li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>  


    <!-- CONTENT -->
    <div class="section ">
        <div class="content-wrap">
            <div class="container">
                <div class="row">
                    
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="single-news">
                        <div class="row" style="float: left;width: 100%; margin-bottom: 25px">
    <!-- <div class="col-md-3">
    </div> -->
    <div class="col-md-12">
<div class="">

            <div class="events-widget" style="line-height: 30px;">
                    <div class="widget-title ">Profile Details</div>
             <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="title"><span>Full Name</span></div>
                <div class="data-content"><?php echo e($users[0]->sname); ?></div>
              </div>

               <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="title"><i class="lni-envelope"></i><span>Email Address</span></div>
                <div class="data-content"><?php echo e($users[0]->email); ?></div>
              </div>
              <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="title"><i class="lni-phone-handset"></i><span>Mobile</span></div>
                <div class="data-content"><?php echo e($users[0]->mobile); ?></div>
              </div>
              <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="title"><i class="lni-phone-handset"></i><span>Gender</span></div>
                <div class="data-content"><?php echo e($users[0]->gender); ?></div>
              </div>
              <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="title"><i class="lni-phone-handset"></i><span>Education</span></div>
                <div class="data-content"><?php echo e($users[0]->education); ?></div>
              </div>
             <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="title"><i class="lni-map-marker"></i><span>Address</span></div>
                <div class="data-content"><?php echo e($users[0]->address); ?></div>
              </div>
              <div class="single-profile-data d-flex align-items-center justify-content-between">
                <div class="title"><i class="lni-envelope"></i><span>Status</span></div>
                <div class="data-content"><span class="db-done"><?php echo e($users[0]->sstatus); ?></span>                                </div>
              </div>
                <div class="single-profile-data d-flex align-items-center justify-content-between">
             <a class="btn btn-primary btn-block block-btn bb" href="<?php echo e(url('customer/edit_profile')); ?>" >&nbsp;Edit Profile</a>
         </div>
            </div>
          </div>

    </div>
    <!-- <div class="col-md-3">
    </div> -->
</div>
                            <div class="spacer-30"></div>

                        
                          
                            
                        
                            
                        
                            

                        </div>
                    </div>
             

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<style >
    .bb
    {
        width: 25%!important; margin: auto;
    }
    .col-sm-12.col-md-12.col-lg-9
    {
        padding-right: 15px;
    }
    @media (max-width: 767px)
    {
        .bb
        {
            width: 100%!important;
        }
        .col-sm-12.col-md-12.col-lg-9
    {
        padding-right: 0px;
    }
    }
</style>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projects\fitkid.com\resources\views/profile.blade.php ENDPATH**/ ?>