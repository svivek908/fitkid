<?php $__env->startSection('content'); ?>
  <?php 
   use App\Http\Controllers\HomeController;
        $user = HomeController::get_user();
        ?>
    <!-- LOAD PAGE -->
  <style type="text/css">
    a.btn.btn-secondary {
            font-size: 14px;
            color: #ffffff;
            padding: 14px 37px;
            border: 0;
            margin-right: 8px;
            min-width: 130px;
            -webkit-border-radius: 30px;
            -moz-border-radius: 30px;
            -ms-border-radius: 30px;
            border-radius: 30px;
        }
        .btn-secondary:hover {
    background-color: #fc1e0e;
    color: #ffffff!important;
}
  </style>
  <!-- BANNER -->
    <div class="section banner-page" data-background="<?php echo e(asset('images/banner-single.jpg')); ?>">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page"><?php echo e(__('messages.Courses')); ?></div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('messages.Home')); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.Courses')); ?></li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>

    <!-- OUR ARTICLES -->
    <div class="">
        <div class="content-wrap">
            <form method="get">
            <div class="container">
                <div class="form-group" style="width: 25%;float: left;margin-right: 12px;">
                <label><?php echo e(__('messages.Gender')); ?></label>
                <select class="form-control" name="gender">
                   <option value="boy"><?php echo e(__('messages.boy')); ?></option> 
                     <option value="girl"><?php echo e(__('messages.girl')); ?></option>
                       <option value="unisex"><?php echo e(__('messages.unisex')); ?></option>
                </select>
                </div>
                <div class="form-group" style="width: 25%;float: left;margin-right: 12px;">
                <label><?php echo e(__('messages.Class Type')); ?></label>
                <select class="form-control" name="class_type">
                    <?php if($class_type): ?>
                    <?php $__currentLoopData = $class_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($ct->type); ?>"><?php echo e($ct->type); ?></option> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>        
                </select>
                </div>
                <div  class="form-group"  style="width: 44%;float: left;margin-right: 12px; margin-top:2%;">
                <button class="btn btn-secondary bb"><?php echo e(__('messages.Submit')); ?></button>
                </div>
            </div>
            </form>
            <div class="container" style="float:left; width:100%;">

                <div class="row mt-4">
                    <?php if($course): ?>
                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Item <?php echo e($key); ?> -->
                    <div class="col-sm-12 col-md-6 col-lg-4">
                        <div class="rs-class-box mb-5">
                            <div class="media-box">
                                <img src="<?php echo e(asset('admin-assets/course').'/'.$courses->image); ?>" alt="" class="img-fluid">
                            </div>
                            <div class="body-box">
                                <div class="class-name">
                                    <div class="title"><?php echo e($courses->name); ?></div>
                                    <div class="price"><?php echo e($courses->fees); ?>&nbsp;SAR</div>
                                </div>
                            
                                 <div class="open-class">
                               <!--  <a class="btn btn-secondary <?php if($user): ?><?php echo e('details'); ?><?php endif; ?>" data-course_id='<?php echo e($courses->id); ?>'>Buy now</a> -->
                                <a href="<?php echo e(url('course_details').'/'.$courses->id); ?>" class="btn btn-secondary bb" style="min-width: 160px;"><?php echo e(__('messages.More details')); ?></a>
                                 </div>
                                <div class="detail">
                                    <div class="age col"><?php echo e(__('messages.Age')); ?> <?php echo e($courses->age_from); ?>-<?php echo e($courses->age_to); ?> <?php echo e(__('messages.years')); ?></div>
                                    <div class="size col"><?php echo e(__('messages.Class Size')); ?> <?php echo e($courses->class_size); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
          

                </div>              

            </div>
        </div>
    </div>

<div class="modal" id="prizePopup" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form class="form-contact" action="<?php echo e(route('add_student_batch')); ?>" method="POST" id="course_buy" onsubmit="return false;">
      <?php echo csrf_field(); ?> 
      <div class="modal-header">
        <h5 class="modal-title"><?php echo e(__('messages.Class time')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p id="slot_heading"><?php echo e(__('messages.Please select time')); ?></p>

        <input type="hidden" name="course_id" class="course_id">
        <div id="time_slot">
            
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary"><?php echo e(__('messages.Save changes')); ?></button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('messages.Close')); ?></button>
      </div>
    </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
 <?php $__env->startSection('script'); ?>
  <script type="text/javascript">
       $(document).ready(function() {

         $('.details').click(function()
          {
            var mid = $(this).attr('data-course_id');
            $.ajax({
              url:"<?php echo e(url('customer/get_course_detail')); ?>?c_id="+mid,
              type: "GET",
              dataType: "html",
              success: function(response) 
              {
                var myJSON = JSON.parse(response);
                  if(myJSON.result == true)
                  {
                    $('#time_slot').empty();
                    if(myJSON.data.length != 0){ 
                    $('#slot_heading').show();
                    $.each(myJSON.data, function( key, value ) {
                    $('#time_slot').append('<div><input type="radio" name="batch_id" value="'+value.id+'"><span style="color: #000;margin-left:5px;">'+value.open_time+'-'+value.close_time+'</span></div>')
                    });
                    }
                    else
                    {
                      $('#slot_heading').hide();
                      $('#time_slot').append('<div><span style="color: #000;margin-left:5px;">No time slot available for this course</span></div>')
                    }
                  $('.course_id').val(myJSON.course_id);
                  $('#prizePopup').modal('show');
                }
              },
              error: function(response)
              {
                console.log(response);
              }       
            });
         });  
      $("#course_buy").validate({
           rules: {
               
            },
             messages: {

            },
            submitHandler: function(a) {
            
                $.ajax({
                    type: "POST",
                    url:"<?php echo e(route('add_student_batch')); ?>",
                    data: $(a).serialize(),
                    success: function(a) {
                    if(a.result == true)
                    { 
                        console.log(404);
                    }
                   },
                    error: function(a) {
                     
                    }
                })
            }
        })
    }); 
     </script>
     <?php $__env->stopSection(); ?>

     <style >
    .bb
    {
        width: 25%!important; margin: auto;
    }
    .col-sm-12.col-md-12.col-lg-9
    {
        padding-right: 15px;
    }
    @media (max-width: 767px)
    {
        .bb
        {
            width: 100%!important;
        }
        .col-sm-12.col-md-12.col-lg-9
    {
        padding-right: 0px;
    }
    .form-group {
    width: 100% !important;
}
    }
    .footer {
    background-color: #F1C22E;
    color: #ffffff;
    background-size: cover;
    background-position: center;
    float: left;
    width: 100%;
}
.bg-tertiary {
    background-color: #16C3B0 !important;
    float: left;
    width: 100%;
}

</style>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/itsergzs/public_html/fitkid/resources/views/course.blade.php ENDPATH**/ ?>