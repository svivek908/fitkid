<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  <style type="text/css">

    .form-group a {
    color: #fd4d40;
}
.pb-5, .py-5 {
    padding-bottom: 3rem!important;
    margin-bottom: 0;
}
      @media (min-width: 768px)
      {
        a.btn.btn-secondary
        {
            margin-left: 25%;
        }
      }
      .help-block.with-errors p {
    color: red;
}
  </style>

 <div id="contact">
        <div class="content-wrap pb-0">
          <div class="section banner-page" data-background="http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg" style="background-image: url(&quot;http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg&quot;);">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page"><?php echo e(__('messages.Login')); ?></div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('messages.Home')); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.Login')); ?></li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>
  </div>
            <div class="container">
                <div class="row">
                        <div class="col-12 col-md-4">
                            <img src="<?php echo e(asset('images/kid.png')); ?>" style="width: 100%;margin-top: -20px">
                        </div>
                        
                    <div class="col-12 col-md-8">
                        <div class="bg">
                       <!--  <h2 class="section-heading text-center mb-5" style="text-align: left!important;">
                            Login
                        </h2> -->
                           <?php if(session()->has('message')): ?>
                                       <div class="alert alert-success">
                                           <?php echo e(session()->get('message')); ?>

                                       </div>
                             <?php elseif(session()->has('emessage')): ?>
                                       <div class="alert alert-danger">
                                           <?php echo e(session()->get('emessage')); ?>

                                       </div>
                             <?php endif; ?>
                        <form class="form-contact" action="<?php echo e(route('user_auth')); ?>" method="POST" id="loginform123">
                           <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="email" placeholder="<?php echo e(__('messages.Email Address')); ?>" required=""  name="email" value="<?php echo e(old('email')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('email')): ?>
                                              <p><?php echo e($errors->first('email')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <input type="password" class="form-control" id="password" placeholder="<?php echo e(__('messages.Password')); ?>" name="password" required="" value="<?php echo e(old('password')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('password')): ?>
                                              <p><?php echo e($errors->first('password')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                               <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                      <p style="float: left;" class="yy"><?php echo e(__("messages.Don't have an account ??")); ?> <a href="<?php echo e(url('user_register')); ?>" ><?php echo e(__('messages.Register here')); ?></a></p>
                                      <p ><a class="forgot-link" href="<?php echo e(url('/forgot_password')); ?>"><?php echo e(__('messages.Forgot your password?')); ?></a></p>
                                    </div>
                                </div>

                            </div>
                            
                            <div class="form-group">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-primary disabled btn4" style="pointer-events: all; cursor: pointer;"><?php echo e(__('messages.Login')); ?></button>
                            </div>
                        </form>
                        

                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<style>
  .content-wrap {
    padding-bottom: 80px!important; 
    margin-bottom: 80px;
}
.pb-0, .py-0
{
  padding: unset!important;
}


.bg {
    float: left;
    width: 100%;
    background-color: #f8f8f8;
    padding: 50px;
    margin-bottom: 20px;
}
</style>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/itsergzs/public_html/fitkid/resources/views/login.blade.php ENDPATH**/ ?>