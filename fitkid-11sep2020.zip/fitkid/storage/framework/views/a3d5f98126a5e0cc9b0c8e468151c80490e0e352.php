<?php $__env->startSection('content'); ?>

    <!-- LOAD PAGE -->
  <style type="text/css">
    .content-wrap {
    padding: 80px 0;
    margin-bottom: 0;
}
      @media (min-width: 768px)
      {
        a.btn.btn-secondary
        {
            margin-left: 25%;
        }
      }
      .help-block.with-errors p {
    color: red;
      }
      .form-label
      {
    color: #000;
    font-weight: 600;
      }
      .form-group a {
    color: #fd4d40;
}

  </style>

 <div id="contact">
        <div class="content-wrap pb-0">
<div class="section banner-page" data-background="http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg" style="background-image: url(&quot;http://116.206.148.54/projects/fitkid.com/public//images/banner-single.jpg&quot;);">
        <div class="content-wrap pos-relative">
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <div class="title-page">Register</div>
            </div>
            <div class="d-flex justify-content-center bd-highlight mb-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb ">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">register</li>
                  </ol>
                </nav>
            </div>
        </div>
    </div>
  </div>
            <div class="container">

                <div class="row">
                    <div class="col-12 col-md-5">
                      
                        <img src="http://116.206.148.54/projects/fitkid.com/public//images/kid.jpg" style="width: 100%; margin-top: -35px">
                        <?php if(session()->has('message')): ?>
                                       <div class="alert alert-success">
                                           <?php echo e(session()->get('message')); ?>

                                       </div>
                             <?php elseif(session()->has('emessage')): ?>
                                       <div class="alert alert-danger">
                                           <?php echo e(session()->get('emessage')); ?>

                                       </div>
                             <?php endif; ?>
                           </div>
                           <div class="col-12 col-md-7">
                              <!-- <h2 class="section-heading text-center mb-5" style="text-align: left!important;"> -->
                          
                        </h2>
                        <form class="form-contact" action="<?php echo e(route('create')); ?>" method="POST">
                           <?php echo csrf_field(); ?>
                            <div class="row">
                           
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Name</label>
                                        <input type="text" class="form-control" id="name" placeholder="Enter student name" required=""  name="name" value="<?php echo e(old('name')); ?>">
                                    
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('name')): ?>
                                              <p><?php echo e($errors->first('name')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" placeholder="Enter student email" required=""  name="email" value="<?php echo e(old('email')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('email')): ?>
                                              <p><?php echo e($errors->first('email')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                       <label class="form-label">Mobile</label>
                                        <input type="number" class="form-control" id="mobile" placeholder="Enter your mobile number" required=""  name="mobile" value="<?php echo e(old('mobile')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('mobile')): ?>
                                              <p><?php echo e($errors->first('mobile')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                            

                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label">Password</label>
                                        <input type="password" class="form-control" id="password" placeholder="Password" name="password" required="" value="<?php echo e(old('password')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('password')): ?>
                                              <p><?php echo e($errors->first('password')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label" style="float: left;width: 100%; margin-bottom: 15px;">Gender</label>
                                        <input type="radio" class="" name="gender" value="Male" checked="">Male
                                        <input type="radio" class="" name="gender" value="FeMale" style="margin-left: 10px">Female
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('gender')): ?>
                                              <p><?php echo e($errors->first('gender')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                 <div class="col-sm-6 col-md-6">
                                    <div class="form-group">
                                      <label class="form-label">Education</label>
                                        <input type="text" class="form-control" id="education" placeholder="education" name="education" required="" value="<?php echo e(old('education')); ?>">
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('education')): ?>
                                              <p><?php echo e($errors->first('education')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                 

                               <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                      <label class="form-label">Address</label>
                                        <textarea  class="form-control" id="address" placeholder="Enter student address" required=""  name="address" value=""><?php echo e(old('address')); ?></textarea>
                                        <div class="help-block with-errors">
                                              <?php if($errors->has('address')): ?>
                                              <p><?php echo e($errors->first('address')); ?></p>
                                              <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            
                               <div class="col-sm-12 col-md-12">
                                    <div class="form-group">
                                      <p>Already have an account ?? <a href="<?php echo e(url('user_login')); ?>">Sign in</a></p>
                                    </div>
                                </div>

                            </div>
                            
                            <div class="form-group">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-primary disabled" style="pointer-events: all; cursor: pointer;">Register</button>
                            </div>
                        </form>
                        <div class="spacer-content"></div>

                    </div>
                    
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<style>
  .content-wrap {
    padding-bottom: 80px!important; 
    margin-bottom: 80px;
}
.pb-0, .py-0
{
  padding: unset!important;
}
.form-label {
    color: #000;
    font-weight: 600;
    display: none;
}
input[type=checkbox], input[type=radio] {
    box-sizing: border-box;
    padding: 0;
    padding-right: 12px;
    margin-right: 5px;
    margin-top: 15px;
    padding-top: 9px;
}
</style>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Projects\fitkid.com\resources\views/register.blade.php ENDPATH**/ ?>