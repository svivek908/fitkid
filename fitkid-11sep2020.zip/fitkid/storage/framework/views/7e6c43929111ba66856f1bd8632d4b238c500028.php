 
<?php $__env->startSection('content'); ?>
<style type="text/css">
    button.btn.btn-danger.btn-rounded {
        background: black !important;
        color: #fff !important;
        border-color: black;
    }
    
    button.btn.btn-danger.btn-rounded a {
        color: #fff;
    }
    button.btn.btn-success.btn-rounded {
    margin-top: 15px;
    FLOAT: LEFT;
}
</style>
<div class="container-fluid">
    <!-- Title -->
    <div class="row heading-bg">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h5 class="txt-dark" style="float: left;">Batches</h5>
        </div>
    </div>

    <!-- /Title -->
    <!-- Row -->
    <div class="row">
        <div class="col-md-4 col-xs-12">
            <div class="panel panel-default card-view">

                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12 col-xs-12">
                                <?php if(session()->has('message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('message')); ?>

                                </div>
                                <?php elseif(session()->has('emessage')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session()->get('emessage')); ?>

                                </div>
                                <?php endif; ?>
                                <div class="form-wrap">
                                    <?php if(isset($mc)): ?>
                                    <form action="<?php echo url('admin/update_batch', $mc->id );; ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Select Course</label>
                                                <div>
                                                 <select class="form-control" name="course_id">
                                                   <?php if($course): ?>
                                                   <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($val->id); ?>" <?php if($mc->id == $val->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($val->name); ?></option>
                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   <?php endif; ?>
                                                 </select>
                                                </div>
                                            </div>
                                        </div>
                                  
                                        <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Open time</label>
                                                <div>
                                                    <input type="time" name="open_time" class="form-control" value="<?php echo e($mc->open_time); ?>"> <?php if($errors->has('open_time')): ?>
                                                    <p class="error"><?php echo e($errors->first('open_time')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Close time</label>
                                                <div>
                                                    <input type="time" name="close_time" class="form-control" value="<?php echo e($mc->close_time); ?>"> <?php if($errors->has('close_time')): ?>
                                                    <p class="error"><?php echo e($errors->first('close_time')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                         <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Start date</label>
                                                <div>
                                                    <input type="date" name="start_date" class="form-control"  value="<?php echo e($mc->start_date); ?>"> <?php if($errors->has('start_date')): ?>
                                                    <p class="error"><?php echo e($errors->first('start_date')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">End date</label>
                                                <div>
                                                    <input type="date" name="end_date" class="form-control"  value="<?php echo e($mc->end_date); ?>"> <?php if($errors->has('end_date')): ?>
                                                    <p class="error"><?php echo e($errors->first('end_date')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Class strength</label>
                                                <div>
                                                    <input type="number" name="class_size" class="form-control"  value="<?php echo e($mc->class_size); ?>"> <?php if($errors->has('class_size')): ?>
                                                    <p class="error"><?php echo e($errors->first('class_size')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-12 col-xs-12 text-right">
                                            <button class="btn  btn-success btn-rounded"><i class="mdi mdi-content-save  mr-5"></i>Update </button>
                                        </div>
                                    </form>
                                    <?php else: ?>
                                    <form class="form-horizontal" method="POST" action="<?php echo url('admin/add_batch'); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>

                                        <div class="col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Select Course</label>
                                                <div>
                                                 <select class="form-control" name="course_id">
                                                   <?php if($course): ?>
                                                   <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($val->id); ?>"><?php echo e($val->name); ?></option>
                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   <?php endif; ?>
                                                 </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Open time</label>
                                                <div>
                                                    <input type="time" name="open_time" class="form-control" > <?php if($errors->has('open_time')): ?>
                                                    <p class="error"><?php echo e($errors->first('open_time')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Close time</label>
                                                <div>
                                                    <input type="time" name="close_time" class="form-control" > <?php if($errors->has('close_time')): ?>
                                                    <p class="error"><?php echo e($errors->first('close_time')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Start date</label>
                                                <div>
                                                    <input type="date" name="start_date" class="form-control" > <?php if($errors->has('start_date')): ?>
                                                    <p class="error"><?php echo e($errors->first('start_date')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">End date</label>
                                                <div>
                                                    <input type="date" name="end_date" class="form-control" > <?php if($errors->has('end_date')): ?>
                                                    <p class="error"><?php echo e($errors->first('end_date')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12 col-xs-12">
                                            <div class="form-group">
                                                <label class="control-label">Class strength</label>
                                                <div>
                                                    <input type="number" name="class_size" class="form-control" > <?php if($errors->has('class_size')): ?>
                                                    <p class="error"><?php echo e($errors->first('class_size')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-12 col-xs-12 text-left" style="padding-left: 0">
                                            <button class="btn  btn-success btn-rounded"><i class="mdi mdi-content-save  mr-5"></i> Save </button>
                                        </div>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xs-8">
            <div class="panel panel-default card-view">

                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="datatable-responsive table-responsive">
                            <table id="simpletable" class="table table-striped table-bordered nowrap">
                                <thead>
                                    <tr>

                                        <th>Batch Id</th>
                                        <th>Course Name</th>
                                        <th>Open time</th>
                                        <th>Close time</th>
                                        <th>Expire in</th>
                                        <th>Class Size</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($data): ?> <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo $mc->id;; ?></td>
                                        <td><?php echo $mc->cname;; ?></td>
                                        <td><?php echo $mc->open_time;; ?></td>
                                        <td><?php echo $mc->close_time;; ?></td>
                                        <td><?php echo $mc->expiry_day;; ?></td>
                                        <td><?php echo $mc->class_size;; ?></td>
                                      
                                        <td>
                                         <i class="fa fa-pencil data-table-edit" data-id="<?php echo $mc->id;; ?>" data-editurl="<?php echo e(url('admin/edit_batch')); ?>" title="Edit"> </i>
                                         <i class="fa fa-eye  data-table-edit" data-id="<?php echo $mc->id;; ?>" data-editurl="<?php echo e(url('admin/view-batch')); ?>" title="View Batch Details"></i>
                                         <i class="fa fa-trash delete" data-id="<?php echo $mc->id;; ?>" data-url="<?php echo e(url('admin/delete_batch')); ?>" data-redirecturl="<?php echo e(url('admin/batch')); ?>" title="Delete"> </i>
                                         <a href="<?php echo e(url('admin/attend_batch').'/'.$mc->id); ?>"><i class="fa fa-clock-o" data-id="<?php echo $mc->id;; ?>" data-url="<?php echo e(url('admin/attend_batch')); ?>" data-redirecturl="<?php echo e(url('admin/batch')); ?>" title="Attendence"> </i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                         <th>Batch Id</th>
                                        <th>Course Name</th>
                                        <th>Open time</th>
                                        <th>Close time</th>
                                        <th>Expire in</th>
                                        <th>Class Size</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<style>
    table.dataTable.nowrap th, table.dataTable.nowrap td {
    white-space: unset!important;
    width: unset;
}
</style>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fitkid.com\resources\views/admin/batch.blade.php ENDPATH**/ ?>