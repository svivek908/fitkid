<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>E-auction|admin</title>
<meta name="description" content="" />
<meta name="keywords" content="admin, admin dashboard, admin template" />
<meta name="author" content="SRGIT"/>
<!-- Favicon -->
<link rel="shortcut icon" href="images/favicon.png">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Custom CSS -->
<link href="plugins/assets/css/default.css" rel="stylesheet" type="text/css">
</head>