<?php

namespace App\AdminModel;

use Illuminate\Database\Eloquent\Model;

class TestiModel extends Model
{
    protected $table = 'testimonial';
    protected $guarded = ['id'];

}
